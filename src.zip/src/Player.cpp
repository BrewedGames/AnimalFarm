#include "Player.h"

Player::Player(Manager& manager, const std::string& name) : health(100)
{
	playerEntity = &manager.addEntity(name);
	sprite = &playerEntity->addComponent<SpriteComponent>();
	collider = &playerEntity->addComponent<ColliderComponent>();
	audio = &playerEntity->addComponent<AudioComponent>();

	sprite->LoadSprite("./static/Sample_SpriteSheet.bmp", 100, 100, Vec3(40, 100, 1));
	collider->setTag((char)"Player");//cast because owell
	collider->AddCapsuleCollider(sprite->getPos().x, sprite->getPos().y, 50, 100);
}

void Player::setHealth(int healthValue) {
	health = healthValue;
}

int Player::getHealth() const {
	return health;
}

void Player::setPosition(const Vec3& pos) {
	sprite->setPos(pos);
	collider->setPos(pos);
}

Vec3 Player::getPosition() const {
	return sprite->getPos();
}

void Player::update(float deltaTime) {
	sprite->Update(deltaTime);
	collider->Update(deltaTime);
}

void Player::render() const {
	sprite->Render();
}
