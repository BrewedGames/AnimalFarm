#pragma once

#include "ECS.h"
#include "ECSComponents.h"
#include <iostream>
#include "math.h"

class Player
{
public:
	Player(Manager& manager, const std::string& name);

	void setHealth(int health);
	int getHealth() const;

	void setPosition(const Vec3& pos);
	Vec3 getPosition() const;

	void update(float deltaTime);
	void render() const;

private:
	int health;
	Entity* playerEntity;
	SpriteComponent* sprite;
	ColliderComponent* collider;
	AudioComponent* audio;
};

