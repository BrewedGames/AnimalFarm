_G.player = manager:addEntity("Player")--global

local playerSprite = _G.player:addSpriteComponent()
local playerCollider = _G.player:addColliderComponent()

local currentHealth = 100;
local maxHealth = 100;
print("Attempting to load player sprite...")


playerSprite:loadSprite("./static/Sample_SpriteSheet.bmp", 100, 100, Vec3(40, 100, 0), true, 32, 8, 100)

playerCollider:setTag("Player")
playerCollider:addCapsuleCollider(playerSprite:getPos().x, playerSprite:getPos().y, 50, 100)

playerSprite:setAnimation("WalkBack", 0, 7, 100)
playerSprite:setAnimation("WalkLeft", 8, 15, 100)
playerSprite:setAnimation("WalkRight", 16, 23, 100)
playerSprite:setAnimation("WalkFront", 24, 31, 100)

function _G.updateHealth(damage)
    currentHealth = currentHealth - damage;
    if currentHealth < 0 then
        currentHealth = maxHealth;--reset for now
    end
end


local key_states = {}

function _G.handlePlayerInput(event)
    if event.type == "keydown" then
        key_states[event.key] = true
        if key_states["s"] then
            playerSprite:clearAnimation()
            playerSprite:playAnimation("WalkBack")
        end
        if key_states["d"] then
            playerSprite:clearAnimation()
            playerSprite:playAnimation("WalkRight")
        end
        if key_states["w"] then
            playerSprite:clearAnimation()
            playerSprite:playAnimation("WalkFront")
        end
        if key_states["a"] then
            playerSprite:clearAnimation()
            playerSprite:playAnimation("WalkLeft")
        end
    elseif event.type == "keyup" then
        playerSprite:clearAnimation()
        key_states[event.key] = false
    end
end

function _G.updatePlayerMovement(delta_time)

    local newPos = playerSprite:getPos() 

    if key_states["s"] then
        newPos.y = newPos.y - 1
    end
    if key_states["d"] then
        newPos.x = newPos.x + 1
    end
    if key_states["w"] then
        newPos.y = newPos.y + 1
    end
    if key_states["a"] then
        newPos.x = newPos.x - 1
    end

    playerCollider:setPos(newPos)
    playerSprite:setPos(newPos)
    

end
